import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { user } from 'src/app/interface/user.interface';

@Component({
  selector: 'app-user-input',
  templateUrl: './user-input.component.html',
  styleUrls: ['./user-input.component.css']
})
export class UserInputComponent implements OnInit {
  submitted = false;
  reactiveform = new FormGroup({
    name: new FormControl('', Validators.required),
    dob: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    gender: new FormControl('', Validators.required),
    address: new FormControl('', Validators.required),
    pin: new FormControl('', [Validators.required, Validators.maxLength(6)])
  })
  @Output() saveUser = new EventEmitter<user>();
  constructor() { }

  ngOnInit(): void {
  }
  get reactiveformControl() {
    return this.reactiveform.controls;
  }
  onSubmit(){
    this.submitted = true;
    if(this.reactiveform.valid){
      this.saveUser.emit(this.reactiveform.value);
    }
  }
  onReset(){
    this.reactiveform.reset();
  }
}
