import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserListingComponent } from './user-listing/user-listing.component';
import { EditComponent } from './edit/edit.component';
import { DeleteComponent } from './delete/delete.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    UserListingComponent,
    EditComponent,
    DeleteComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [
    UserListingComponent,
    EditComponent,
    DeleteComponent
  ]
})
export class FooterModule { }
