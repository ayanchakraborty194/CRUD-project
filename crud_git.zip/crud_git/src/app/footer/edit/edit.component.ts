import { Component, Input, OnInit } from '@angular/core';
import {user} from 'src/app/interface/user.interface'

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  @Input() edit_data!: Array<user>;
  constructor() { }

  ngOnInit(): void {
  }
  onsubmit(){
    console.log(this.edit_data);
  }
}
