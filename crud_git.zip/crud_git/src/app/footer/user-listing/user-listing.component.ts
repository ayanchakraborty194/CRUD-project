import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {user} from 'src/app/interface/user.interface';

@Component({
  selector: 'app-user-listing',
  templateUrl: './user-listing.component.html',
  styleUrls: ['./user-listing.component.css']
})
export class UserListingComponent implements OnInit {
  target_data!: Array<string | any>
  @Input() userArr!: Array<string | any>;
  EditComponent: any;

  @Output() editArr =new EventEmitter <user> ();
  constructor() { }

  ngOnInit(): void {
    // console.log(this.userArr);
  }
  onEdit(index:number){
    this.editArr.emit(this.userArr[index]);
    console.log(this.editArr);

  }
  onDelete(index:number){
    this.userArr.splice(index,1);
  }
}
