export interface user{
    name:string;
    dob:any;
    email:any;
    gender:string;
    address:string;
    pin:any;
  }[];