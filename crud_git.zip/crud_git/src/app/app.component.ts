import { Component } from '@angular/core';
import {user} from 'src/app/interface/user.interface'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'crud-test';
  userArray:any[]=[];
  edit!:Array<user>;
  createuser(scope:any){
    this.userArray.push(scope);
    // console.log(this.userArray)
  }
  editUser(scope:any){
    this.edit.push(scope);
  }
}

